TRACK_TERMS = ["trump", "clinton", "sanders", "hillary clinton", "bernie", "donald trump"]
CONNECTION_STRING = ""
CSV_NAME = "tdatabase.csv"
TABLE_NAME = "trump"

try:
    from private import *
except Exception:
    pass