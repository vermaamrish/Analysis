﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace T001.Models
    {
    public class GetLocation
        {
        }
    }