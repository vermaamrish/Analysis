﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace T001.Models
    {
    public class _MostDetails
        {
        public string ProfileIcon;
        public string UserName;
        public string TwitteHandle;
        public DateTime TweetDate;
        public string TweetText;
        public int Retweet;
        public int Favourite;
        public string url;
        }
    }