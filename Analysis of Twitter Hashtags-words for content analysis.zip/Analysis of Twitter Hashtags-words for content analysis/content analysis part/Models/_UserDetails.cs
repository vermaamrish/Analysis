﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace T001.Models
    {
    public class _UserDetails
        {
        public string ProfileIcon;
        public string UserName;
        public string TwitteHandle;
        public string url;
        public DateTime tweetDate;

        // As per the needs
        public int Retweet;
        public int Replies;
        public int Mention;
        
        public int Follower;
        public int Following;
        public int tweet;
        }
    }